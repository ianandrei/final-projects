<?php

$con = mysqli_connect("localhost","root","","group_2") or die("Couldn't connect");

?>